/* Тренажёр Б.7.1 — сервис-воркер: офлайн-работа и защита от устаревших версий.

   Стратегия:
     • страницы (index.html, all-in-one.html, test.html) и код (app.js, test.js) — сначала сеть,
       кэш только если сети нет. Так новая версия после обновления сайта подхватывается сразу,
       а не «залипает» старая.
     • картинки и манифест — сначала кэш (они меняются редко), фоном обновляем.
   Старый кэш удаляется при активации новой версии. */
const CACHE = 'b71-trainer-v2';
const PRECACHE = [
  './index.html', './app.js', './all-in-one.html', './test.html', './test.js',
  './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png'
];

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE)
      .then(function (c) { return Promise.all(PRECACHE.map(function (u) { return c.add(u).catch(function () { }); })); })
      .then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys()
      .then(function (keys) { return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })); })
      .then(function () { return self.clients.claim(); })
  );
});

function isCode(req) {
  if (req.mode === 'navigate') return true;
  const u = new URL(req.url);
  return /\.(html|js|webmanifest)$/i.test(u.pathname) || u.pathname === '/' ;
}

self.addEventListener('fetch', function (e) {
  const req = e.request;
  if (req.method !== 'GET') return;
  if (new URL(req.url).origin !== self.location.origin) return;

  /* Страницы и код — сеть в приоритете */
  if (isCode(req)) {
    e.respondWith(
      fetch(req).then(function (r) {
        const cp = r.clone();
        caches.open(CACHE).then(function (c) { c.put(req, cp); });
        return r;
      }).catch(function () {
        return caches.match(req).then(function (r) {
          return r || caches.match('./index.html');
        });
      })
    );
    return;
  }

  /* Картинки, манифест — кэш в приоритете, обновление фоном */
  e.respondWith(
    caches.match(req).then(function (cached) {
      const net = fetch(req).then(function (resp) {
        if (resp && resp.ok) { const cp = resp.clone(); caches.open(CACHE).then(function (c) { c.put(req, cp); }); }
        return resp;
      }).catch(function () { return cached; });
      return cached || net;
    })
  );
});
