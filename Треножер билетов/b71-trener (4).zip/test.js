(function () {
  var out = [];
  var report = document.getElementById('report');
  var verdict = document.getElementById('verdict');

  function item(status, title, note) {
    out.push((status === 'ok' ? '[OK] ' : status === 'warn' ? '[?] ' : '[ОШИБКА] ') + title + (note ? ' — ' + note.replace(/<[^>]+>/g, '') : ''));
    var mk = status === 'ok' ? '✓' : status === 'warn' ? '!' : '✕';
    return '<div class="item ' + status + '"><div class="mk">' + mk + '</div><div class="t"><b>' + title + '</b>' +
      (note ? '<span>' + note + '</span>' : '') + '</div></div>';
  }
  function deps() {
    try { document.documentElement.dataset.theme; return 'ok'; } catch (e) { return 'bad'; }
  }
  function lsCheck() {
    try {
      var k = '__b71_test__', v = 'значение';
      localStorage.setItem(k, v);
      var got = localStorage.getItem(k) === v;
      localStorage.removeItem(k);
      return got ? 'ok' : 'bad';
    } catch (e) { return 'bad:' + (e.name || 'ошибка'); }
  }
  /* Проверка возможностей движка БЕЗ eval/new Function: строгая политика безопасности (CSP)
     их запрещает, и раньше из-за этого список ошибочно сообщал «браузер устарел». */
  function es6() {
    var problems = [];
    if (typeof Promise !== 'function') problems.push('Promise');
    if (typeof Map !== 'function') problems.push('Map');
    if (typeof Set !== 'function') problems.push('Set');
    if (typeof Symbol !== 'function') problems.push('Symbol');
    if (!Object.assign) problems.push('Object.assign');
    if (!Array.prototype.includes) problems.push('Array.includes');
    if (!String.prototype.padStart) problems.push('padStart');
    if (!Number.isInteger) problems.push('Number.isInteger');
    try { var f = function () { return 1; }.bind(null); if (f() !== 1) problems.push('bind'); } catch (e) { problems.push('bind'); }
    return problems;
  }

  function render(extra) {
    var ls = lsCheck();
    var rows = '';
    rows += item('ok', 'JavaScript выполняется', 'Скрипты в браузере включены — значит, тренажёр должен работать.');
    var es6miss = es6();
    rows += item(es6miss.length ? 'bad' : 'ok', 'Поддержка современных возможностей JavaScript',
      es6miss.length ? 'Не поддерживается: ' + es6miss.join(', ') + ' — обновите браузер (Chrome/Edge/Firefox).'
                     : 'Всё нужное на месте (Promise, Map, Set, Symbol, Object.assign и др.).');
    rows += item(ls === 'ok' ? 'ok' : 'bad', 'localStorage — память браузера',
      ls === 'ok' ? 'Статистика, отметки ★ и заметки будут сохраняться между сеансами.'
        : (ls === 'bad:SecurityError' ? 'Данные сайтов заблокированы в настройках браузера — статистика сохраняться не будет.'
          : 'Недоступен. В приватном окне статистика живёт только до закрытия вкладки (' + ls.replace('bad:', '') + ').'));
    rows += item('serviceWorker' in navigator ? 'ok' : 'warn', 'Офлайн-режим (service worker)',
      'serviceWorker' in navigator ? 'Поддерживается: после первого открытия сайт откроется без интернета.' : 'Не поддерживается — сайту потребуется интернет.');
    rows += item('ok', 'Разрешение экрана', window.innerWidth + '×' + window.innerHeight + ', точек на дюйм: ' + (window.devicePixelRatio || 1));
    report.innerHTML = rows + (extra ? extra.join('') : '');
    out.push('[Инфо] ' + navigator.userAgent + ' | экран ' + window.innerWidth + 'x' + window.innerHeight);
    if (extra) out = out.concat(extra);

    if (ls === 'ok') {
      verdict.innerHTML = '<div class="banner ok"><span class="big">✓</span> Браузер в порядке: скрипты и память работают. ' +
        'Открывайте тренажёр — если он всё равно пустой, обновите страницу с очисткой кэша (Ctrl+F5).</div>';
    } else {
      verdict.innerHTML = '<div class="banner bad"><span class="big">!</span> Скрипты работают, но память браузера недоступна: ' +
        'тренажёр откроется, однако результаты, отметки и заметки не сохранятся после закрытия вкладки.</div>';
    }
  }

  /* проверка файлов на хостинге */
  function checkFiles(cb) {
    var extra = [], done = 0, need = 5;
    function finish() { if (++done === need) cb(extra); }

    fetch('index.html', { cache: 'no-store' }).then(function (r) {
      return r.ok ? r.text() : Promise.reject(new Error('HTTP ' + r.status));
    }).then(function (t) {
      var refApp = t.indexOf('script src="app.js"') >= 0 || t.indexOf("script src='app.js'") >= 0;
      var inline = t.indexOf('QUESTIONS_DATA') >= 0;
      extra.push(refApp || inline
        ? item('ok', 'index.html на хостинге', refApp ? 'Страница подключает внешний app.js — это правильный вариант для хостинга.'
                                                     : 'Найдена однофайловая сборка (код внутри страницы).')
        : item('bad', 'index.html на хостинге', 'Страница не подключает app.js и не содержит кода — залейте свежие index.html и app.js.'));
    }).catch(function (e) {
      extra.push(item('bad', 'index.html на хостинге', 'Не удалось загрузить: ' + e.message));
    }).then(finish);

    fetch('app.js', { cache: 'no-store' }).then(function (r) {
      return r.ok ? r.text() : Promise.reject(new Error('HTTP ' + r.status));
    }).then(function (t) {
      var data = t.indexOf('QUESTIONS_DATA') >= 0, app = t.indexOf('__B71_BOOTED') >= 0;
      extra.push(data && app
        ? item('ok', 'app.js — код тренажёра', 'Загружается, размер ' + Math.round(t.length / 1024) + ' КБ, 211 вопросов внутри.')
        : item('bad', 'app.js — код тренажёра', 'Файл есть, но это не та сборка. Залейте свежий app.js рядом с index.html.'));
    }).catch(function (e) {
      extra.push(item('bad', 'app.js — код тренажёра', 'Не загрузился: ' + e.message + '. Без него тренажёр не работает — проверьте, что файл лежит рядом с index.html.'));
    }).then(finish);

    fetch('manifest.webmanifest', { cache: 'no-store' }).then(function (r) {
      extra.push(item(r.ok ? 'ok' : 'warn', 'manifest.webmanifest', r.ok ? 'Есть — установка на телефон как приложение доступна.' : 'Не найден (HTTP ' + r.status + '). Не критично.'));
    }).catch(function () { extra.push(item('warn', 'manifest.webmanifest', 'Не найден. Не критично — тренажёр работает и без него.')); }).then(finish);

    fetch('sw.js', { cache: 'no-store' }).then(function (r) {
      extra.push(item(r.ok ? 'ok' : 'warn', 'sw.js (офлайн-режим)', r.ok ? 'Есть.' : 'Не найден (HTTP ' + r.status + '). Не критично.'));
    }).catch(function () { extra.push(item('warn', 'sw.js (офлайн-режим)', 'Не найден. Не критично.')); }).then(finish);

    fetch('lite.html', { cache: 'no-store' }).then(function (r) {
      return r.ok ? r.text() : Promise.reject(new Error('HTTP ' + r.status));
    }).then(function (t) {
      var qs = (t.match(/class="q"/g) || []).length;
      extra.push(item(qs >= 200 ? 'ok' : 'bad', 'lite.html — версия без JavaScript',
        qs >= 200 ? 'Есть, вопросов: ' + qs + '. Открывается даже при полном запрете скриптов.'
                  : 'Файл найден, но вопросов в нём: ' + qs + ' — залейте полную версию файла.'));
    }).catch(function (e) {
      extra.push(item('warn', 'lite.html — версия без JavaScript', 'Не найден (' + e.message + '). Не критично, но полезен как запасной вариант.'));
    }).then(finish);
  }

  function run() {
    report.innerHTML = '<div class="item"><div class="mk">…</div><div class="t"><b>Выполняю проверки…</b></div></div>';
    verdict.innerHTML = '';
    out = [];
    if (location.protocol === 'file:') {
      render([item('warn', 'Открыто как файл (file://)', 'При открытии из файловой системы установка на телефон и офлайн-режим недоступны, но тренажёр и сохранение работают.')]);
      return;
    }
    checkFiles(render);
  }

  document.getElementById('again').onclick = run;
  document.getElementById('copy').onclick = function () {
    var text = 'Самопроверка тренажёра Б.7.1\n' + out.join('\n');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { alert('Отчёт скопирован в буфер обмена.'); },
        function () { prompt('Скопируйте отчёт:', text); });
    } else { prompt('Скопируйте отчёт:', text); }
  };
  run();
})();
